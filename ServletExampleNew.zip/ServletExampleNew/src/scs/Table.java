package scs;

public class Table {

	String displayTable(int num)
	{
		String s ="";
		for(int i=1;i<=10;i++)
		{
			s = s+ (num*i) +"\n";
		}
		return s;
	}
}
